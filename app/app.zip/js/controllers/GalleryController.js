app.controller('GalleryController', ['$scope', function($scope) {
  $scope.galleries = [
    {
      image: '../../images/img_5.jpg'
    },
    {
      image: '../../images/img_6.jpg'
    },
    {
      image: '../../images/img_7.jpg'
    },
    {
      image: '../../images/img_8.jpg'
    },
    {
      image: '../../images/img_9.jpg'
    },
    {
      image: '../../images/img_17.jpg'
    },
    {
      image: '../../images/img_18.jpg'
    },
    {
      image: '../../images/img_19.jpg'
    }
  ];
}]);
